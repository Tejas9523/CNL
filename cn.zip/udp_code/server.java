import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class server {
    public static void main(String[] args) {
        try {
            // Create a DatagramSocket and bind it to a specific port
            DatagramSocket serverSocket = new DatagramSocket(12345);

            byte[] receiveData = new byte[1024];
            File file = new File("UDP.txt");
            FileOutputStream fileOutputStream = new FileOutputStream(file);

            while (true) {
                // Create a DatagramPacket to receive data from clients
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                // Receive data from client
                serverSocket.receive(receivePacket);

                // Clear the receive buffer
                byte[] data = receivePacket.getData();
                fileOutputStream.write(data,0,receivePacket.getLength());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}