import java.io.FileInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.*;

public class client {
    public static void main(String[] args) {
        try {
            // Get the server's IP address
            InetAddress serverAddress = InetAddress.getByName("localhost");

            // Create a DatagramSocket for the client
            DatagramSocket clientSocket = new DatagramSocket();

            int bytes = 0;
            // Open the File where he located in your pc
            File file = new File("hello.txt");
            FileInputStream fileInputStream
                    = new FileInputStream(file);

           // Here we break file into chunks
            byte[] buffer = new byte[1024];
            while ((bytes = fileInputStream.read(buffer)) != -1) {
                // Send the file to Server Socket
                DatagramPacket packet = new DatagramPacket(buffer,bytes,serverAddress,12345);
                clientSocket.send(packet);
            }
            // close the file here
            fileInputStream.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}