import java.io.*;
import java.net.*;
import java.util.Scanner;

public class server {
    public static void main(String[] args) {
        try {

            ServerSocket serverSocket = new ServerSocket(1);
            System.out.println("Server is listening ...");
            Socket clientsocket = serverSocket.accept();
            System.out.println("Client connected : " + clientsocket.getInetAddress());
            BufferedReader in = new BufferedReader(new InputStreamReader(clientsocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientsocket.getOutputStream(), true);

            while (true) {
                String clientmsg = in.readLine();
                System.out.println("Client Says : " + clientmsg);
                if (clientmsg == "by") {
                    break;
                }
                System.out.println("Enter your msg - ");
                Scanner myObj = new Scanner(System.in);
                String msg = myObj.nextLine();
                if (msg == "by") {
                    break;
                }
                out.println(msg);
            }
            in.close();
            out.close();
            clientsocket.close();
            serverSocket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
