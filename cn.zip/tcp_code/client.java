import java.io.*;
import java.net.*;
import java.util.Scanner;

public class client {
    public static void main(String[] args) {
        try {

            Socket cs = new Socket("localhost", 1);
            BufferedReader in = new BufferedReader(new InputStreamReader(cs.getInputStream()));
            PrintWriter out = new PrintWriter(cs.getOutputStream(), true);
            while (true) {
                System.out.println("Enter your Message - ");
                Scanner myObj = new Scanner(System.in);
                String m = myObj.nextLine();
                if (m == "by") {
                    break;
                }
                out.println(m);
                String servermsg = in.readLine();
                System.out.println("Server Says : " + servermsg);
                if (servermsg == "by") {
                    break;
                }
            }

            in.close();
            out.close();
            cs.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
